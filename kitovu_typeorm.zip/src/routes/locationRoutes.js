const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const { getFarmersCountByLocation } = require("../controllers/locationController");

/**
 * @swagger
 * tags:
 *   name: Distribution
 *   description: APIs for managing locations and farmer counts
 */

/**
 * @swagger
 * /api/locations/farmers-count:
 *   get:
 *     summary: Get the count of farmers inside each location
 *     tags: [Distribution]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: type
 *         schema:
 *           type: string
 *         required: true
 *         description: The type of location (e.g., LGA)
 *       - in: query
 *         name: name
 *         schema:
 *           type: string
 *         required: false
 *         description: The name of the location (optional)
 *     responses:
 *       200:
 *         description: A list of locations with farmer counts
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   name:
 *                     type: string
 *                     description: The name of the location
 *                     example: Location A
 *                   farmer_count:
 *                     type: integer
 *                     description: The number of farmers inside the location
 *                     example: 10
 *                   geom:
 *                     type: object
 *                     description: The geometry of the location (optional)
 *       401:
 *         description: Unauthorized (missing or invalid token)
 *       500:
 *         description: Internal server error
 */
router.get("/locations/farmers-count", auth, getFarmersCountByLocation);

module.exports = router;